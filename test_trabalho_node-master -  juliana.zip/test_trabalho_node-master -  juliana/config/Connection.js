const mongoose = require('mongoose');
const connectionString = 'mongodb+srv://julianafernandes:asdasd@cluster0.6iroq.mongodb.net/final?retryWrites=true&w=majority'

const openConnection = () => mongoose.connect(connectionString, { useNewUrlParser: true })

module.exports = {
    openConnection,
}


