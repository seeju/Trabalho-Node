var express = require('express');
const controllers = require('../controllers/tarefas');
const tarefas = require('../controllers/tarefas');
const Tarefa = require('../models/Tarefas');
var router = express.Router();


router.get('/:nomeList', controllers.tarefas);
router.post('/:nomeList', controllers.criarTarefas);


module.exports = router;