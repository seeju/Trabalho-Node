var express = require('express');
const controllers = require('../controllers/tarefas');
const tarefas = require('../controllers/tarefas');
const Tarefa = require('../models/Tarefas');
const Lista = require('../models/Listas');
var router = express.Router();



//encontra qual tarefa foi escolhida para editar
router.get('/:id', (req, res) => {
      Tarefa.findOne({_id:req.params.id}).then((tarefa) => {
          res.render('edittarefa', {tarefa: tarefa})
    })
})

//rota a ser chamada depois de clicar no botão editar
router.post('/', (req,res) => {
   Tarefa.findOne({_id:req.body.id}).then((tarefa) => {
        
        tarefa.nomeTarefa = req.body.nomeTarefa
        tarefa.descricaoTarefa = req.body.descricaoTarefa

        tarefa.save().then(() => {
        res.redirect(`/tarefas/${nomeList}`);//NÃO ESTA CARREGANDO
        })
})
})

router.post('/deletartarefa', (req,res) => {
    Tarefa.remove({_id: req.body.id}).then(() =>
    res.redirect(`/tarefas/${nomeList}`)//NÃO ESTÁ CARREGANDO
    )}
)

router.post('/deletarlista', (req,res) => {
    Tarefa.remove({this.nomeList})//excluir as tarefas que possuem o nomeLista
    Lista.remove({_id: req.body.id}).then(() =>
    res.redirect(`/tarefas/${nomeList}`)//NÃO ESTÁ CARREGANDO
    )}
)

Tarefa.remove()

module.exports = router;